﻿local template = rf2.executeScript(rf2.radio.template)
local lineSpacing = template.lineSpacing
local yMinLim = rf2.radio.yMinLimit
local x = template.margin
local y = yMinLim - lineSpacing
local inc = { x = function(val) x = x + val return x end, y = function(val) y = y + val return y end }
local labels = {}
local fields = {}

labels[#labels + 1] = { t = "保持机体水平", x = x, y = inc.y(lineSpacing) }
labels[#labels + 1] = { t = "稳定后按",       x = x, y = inc.y(lineSpacing) }
labels[#labels + 1] = { t = "[ENTER] 进行校准, or",     x = x, y = inc.y(lineSpacing) }
labels[#labels + 1] = { t = "[EXIT] 取消",            x = x, y = inc.y(lineSpacing) }
fields[#fields + 1] = { x = x, y = inc.y(lineSpacing), value = "", readOnly = true }

return {
    title  = "加速计校准",
    labels = labels,
    fields = fields,
    init   = rf2.executeScript("acc_cal"),
}

