﻿local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local governorConfig = rf2.useApi("mspGovernorConfig").getDefaults()

x = margin
y = yMinLim - tableSpacing.header

fields[#fields + 1] = { t = "模式",                 x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_mode }
fields[#fields + 1] = { t = "接管油门[%]",    x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_handover_throttle }
fields[#fields + 1] = { t = "缓启动时间",         x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_startup_time }
fields[#fields + 1] = { t = "缓提速时间",         x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_spoolup_time }
if rf2.apiVersion >= 12.08 then
    fields[#fields + 1] = { t = "缓启动最小油门[%]", x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_spoolup_min_throttle }
end
fields[#fields + 1] = { t = "跟踪时间",        x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_tracking_time }
fields[#fields + 1] = { t = "重启时间",        x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_recovery_time }
fields[#fields + 1] = { t = "熄火重启保护时间",      x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_autorotation_bailout_time }
fields[#fields + 1] = { t = "熄火重启超时",           x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_autorotation_timeout }
fields[#fields + 1] = { t = "熄火降落最小进入时间",    x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_autorotation_min_entry_time }
fields[#fields + 1] = { t = "零油门超时",     x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_zero_throttle_timeout }
fields[#fields + 1] = { t = "主旋翼转速讯号超时",    x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_lost_headspeed_timeout }
fields[#fields + 1] = { t = "主旋翼转速滤波器截止",     x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_rpm_filter }
fields[#fields + 1] = { t = "电池电压滤波器截止",  x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_pwr_filter }
fields[#fields + 1] = { t = "TTA控制带宽",        x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_tta_filter }
fields[#fields + 1] = { t = "预补偿带宽",    x = x, y = incY(lineSpacing), sp = x + sp, data = governorConfig.gov_ff_filter }

local function receivedGovernorConfig(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        rf2.useApi("mspGovernorConfig").read(receivedGovernorConfig, self, governorConfig)
    end,
    write = function(self)
        rf2.useApi("mspGovernorConfig").write(governorConfig)
        rf2.settingsSaved(true, true)
    end,
    title       = "定速器",
    labels      = labels,
    fields      = fields
}

