﻿local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
template = nil
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local profileSwitcher = rf2.executeScript("PAGES/helpers/profileSwitcher.lua")
local pidProfile = rf2.useApi("mspPidProfile").getDefaults()
collectgarbage()

fields[#fields + 1] = { t = "目前 PID 配置文件",     x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = profileSwitcher.startPidEditing, postEdit = profileSwitcher.endPidEditing }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "主旋翼",              x = x,            y = incY(lineSpacing) }
fields[#fields + 1] = { t = "集体螺距俯仰增益",      x = x + indent,   y = incY(lineSpacing), sp = x + sp, data = pidProfile[27] }
labels[#labels + 1] = { t = "交叉耦合",          x = x + indent,   y = incY(lineSpacing), bold = false }
fields[#fields + 1] = { t = "增益",                    x = x + indent*2, y = incY(lineSpacing), sp = x + sp, data = pidProfile[33] }
fields[#fields + 1] = { t = "速率[%]",                   x = x + indent*2, y = incY(lineSpacing), sp = x + sp, data = pidProfile[34] }
fields[#fields + 1] = { t = "截止频率",                  x = x + indent*2, y = incY(lineSpacing), sp = x + sp, data = pidProfile[35] }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "航向",              x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "顺时针剎车增益",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[20] }
fields[#fields + 1] = { t = "逆时针剎车增益",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[21] }
fields[#fields + 1] = { t = "预补偿截止频率",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[22] }
fields[#fields + 1] = { t = "循环前馈增益",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[23] }
fields[#fields + 1] = { t = "集体前馈增益",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[24] }
if rf2.apiVersion >= 12.08 then
    fields[#fields + 1] = { t = "惯性预补偿增益",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[41] }
    fields[#fields + 1] = { t = "惯性预补偿截止",      x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[42] }
else
    fields[#fields + 1] = { t = "Coll imp FF gain",    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[25]  }
    fields[#fields + 1] = { t = "Coll imp FF decay",   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[26] }
end

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "教练模式",            x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "回正增益",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[31] }
fields[#fields + 1] = { t = "最大角度",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[32] }
labels[#labels + 1] = { t = "自稳模式",              x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "回正增益",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[28] }
fields[#fields + 1] = { t = "最大角度",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[29] }
labels[#labels + 1] = { t = "半自稳模式",            x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "回正增益",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[30] }

local function receivedPidProfile(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        self.profileSwitcher.getStatus(self)
        rf2.useApi("mspPidProfile").read(receivedPidProfile, self, pidProfile)
    end,
    write = function(self)
        rf2.useApi("mspPidProfile").write(pidProfile)
        rf2.settingsSaved(true, false)
    end,
    title       = "飞行参数 - 其他",
    labels      = labels,
    fields      = fields,
    profileSwitcher = profileSwitcher,

    timer = function(self)
        self.profileSwitcher.checkStatus(self)
    end,
}

