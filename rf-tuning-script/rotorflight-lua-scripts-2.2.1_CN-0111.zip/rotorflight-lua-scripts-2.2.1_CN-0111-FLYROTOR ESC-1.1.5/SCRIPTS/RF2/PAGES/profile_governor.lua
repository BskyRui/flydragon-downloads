﻿local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local profileSwitcher = assert(rf2.loadScript("PAGES/helpers/profileSwitcher.lua"))()
local governorProfile = rf2.useApi("mspGovernorProfile").getDefaults()

fields[#fields + 1] = { t = "目前 PID 配置文件", x = x, y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = profileSwitcher.startPidEditing, postEdit = profileSwitcher.endPidEditing }

incY(lineSpacing * 0.25)
fields[#fields + 1] = { t = "最高转速[rpm]",      x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.headspeed}
fields[#fields + 1] = { t = "最大油门[%]",        x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.max_throttle }
if rf2.apiVersion >= 12.07 then
    fields[#fields + 1] = { t = "最小油门[%]",    x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.min_throttle }
end
fields[#fields + 1] = { t = "主 PID 增益",     x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.gain }
fields[#fields + 1] = { t = "P-增益",              x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.p_gain }
fields[#fields + 1] = { t = "I-增益",              x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.i_gain }
fields[#fields + 1] = { t = "D-增益",              x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.d_gain }
fields[#fields + 1] = { t = "FF-增益",             x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.f_gain }
fields[#fields + 1] = { t = "航向预补偿",        x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.yaw_ff_weight }
fields[#fields + 1] = { t = "循环螺距预补偿",     x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.cyclic_ff_weight }
fields[#fields + 1] = { t = "集体螺距预补偿",       x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.collective_ff_weight }
fields[#fields + 1] = { t = "TTA 增益",            x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.tta_gain }
fields[#fields + 1] = { t = "TTA 增益上限",           x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.tta_limit }

local function receivedGovernorProfile(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        self.profileSwitcher.getStatus(self)
        rf2.useApi("mspGovernorProfile").read(receivedGovernorProfile, self, governorProfile)
    end,
    write = function(self)
        rf2.useApi("mspGovernorProfile").write(governorProfile)
        rf2.settingsSaved(true, false)
    end,
    title       = "飞行参数 - 定速器",
    labels      = labels,
    fields      = fields,
    profileSwitcher = profileSwitcher,

    timer = function(self)
        self.profileSwitcher.checkStatus(self)
    end,
}

