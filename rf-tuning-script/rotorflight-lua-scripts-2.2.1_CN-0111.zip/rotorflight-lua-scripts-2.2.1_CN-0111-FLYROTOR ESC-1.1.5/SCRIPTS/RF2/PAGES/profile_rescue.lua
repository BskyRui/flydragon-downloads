﻿local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local profileSwitcher = rf2.executeScript("PAGES/helpers/profileSwitcher.lua")
local rescueProfile = rf2.useApi("mspRescueProfile").getDefaults()

fields[#fields + 1] = { t = "目前 PID 配置文件", x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = profileSwitcher.startPidEditing, postEdit = profileSwitcher.endPidEditing }

incY(lineSpacing * 0.25)
--fields[#fields + 1] = { t = "启用救援",     x = x,          y = incY(lineSpacing), sp = x + sp, min = 0, max = 2,     vals = { 1 }, table = { [0] = "Off", "On", "Alt hold" } }
fields[#fields + 1] = { t = "启用救援",       x = x,          y = incY(lineSpacing), sp = x + sp, min = 0, data = rescueProfile.mode }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "阶段 1: 紧急拉升",    x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "拉升螺距[%]",  x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.pull_up_collective }
fields[#fields + 1] = { t = "拉升时间[s]",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.pull_up_time }
fields[#fields + 1] = { t = "翻正至正面",     x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.flip_mode }
fields[#fields + 1] = { t = "翻正失败时间[s]",      x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.flip_time }
fields[#fields + 1] = { t = "翻正增益",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.flip_gain }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "阶段 2: 继续爬升",      x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "爬升螺距[%]",    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.climb_collective }
fields[#fields + 1] = { t = "爬升时间[s]",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.climb_time }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "阶段 3: 悬停",      x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "悬停螺距[%]",    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.hover_collective }

incY(lineSpacing * 0.25)
fields[#fields + 1] = { t = "退出时间[s]",           x = x,          y = incY(lineSpacing), sp = x + sp, data = rescueProfile.exit_time }
fields[#fields + 1] = { t = "水平回正增益",       x = x,          y = incY(lineSpacing), sp = x + sp, data = rescueProfile.level_gain }
fields[#fields + 1] = { t = "最大回正速率[°/s]",   x = x,          y = incY(lineSpacing), sp = x + sp, data = rescueProfile.max_setpoint_rate }
fields[#fields + 1] = { t = "最大回正加速度[°/s]",  x = x,          y = incY(lineSpacing), sp = x + sp, data = rescueProfile.max_setpoint_accel }
--[[
labels[#labels + 1] = { t = "高度维持",       x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "悬停高度[m]",      x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.hover_altitude }
fields[#fields + 1] = { t = "P-增益",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.alt_p_gain }
fields[#fields + 1] = { t = "I-增益",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.alt_i_gain }
fields[#fields + 1] = { t = "D-增益",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.alt_d_gain }
fields[#fields + 1] = { t = "最大集体螺距[%]",      x = x + indent, y = incY(lineSpacing), sp = x + sp, data = rescueProfile.max_collective }
--]]

local function receivedRescueProfile(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        self.profileSwitcher.getStatus(self)
        rf2.useApi("mspRescueProfile").read(receivedRescueProfile, self, rescueProfile)
    end,
    write = function(self)
        rf2.useApi("mspRescueProfile").write(rescueProfile)
        rf2.settingsSaved(true, false)
    end,
    title       = "飞行参数 - 救机",
    labels      = labels,
    fields      = fields,
    profileSwitcher = profileSwitcher,

    timer = function(self)
        self.profileSwitcher.checkStatus(self)
    end
}

