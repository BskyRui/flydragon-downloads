local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local mspEscFlyrotor = "mspEscFlyrotor"
local escParameters = rf2.useApi(mspEscFlyrotor).getDefaults()

labels[#labels + 1] = { t = "电调未就绪，等待...",        x = x,          y = incY(lineSpacing) }
labels[#labels + 1] = { t = "---",                       x = x + indent, y = incY(lineSpacing), bold = false }
labels[#labels + 1] = { t = "---",                       x = x + indent, y = incY(lineSpacing), bold = false }
labels[#labels + 1] = { t = "---",                       x = x + indent, y = incY(lineSpacing), bold = false }
labels[#labels + 1] = { t = "---",                       x = x + indent, y = incY(lineSpacing), bold = false }

-- General
labels[#labels + 1] = { t = "基础参数",                  x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "电调模式",                  x = x + indent, y = incY(lineSpacing), sp = x + sp, w = 125, data = escParameters.esc_mode }
fields[#fields + 1] = { t = "锂电池节数 [S]",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.cell_count }
fields[#fields + 1] = { t = "低压保护阈值",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.low_voltage }
fields[#fields + 1] = { t = "温度保护阈值",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.temperature }
fields[#fields + 1] = { t = "SBEC 输出电压",             x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.bec_voltage }
fields[#fields + 1] = { t = "电角度",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.timing }
fields[#fields + 1] = { t = "电机转向",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.motor_direction }
fields[#fields + 1] = { t = "启动力度",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.starting_torque }
fields[#fields + 1] = { t = "响应速度",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.response_speed }
fields[#fields + 1] = { t = "蜂鸣音量",             x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.buzzer_volume }
fields[#fields + 1] = { t = "电流增益",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.current_gain }
fields[#fields + 1] = { t = "散热风扇模式",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.fan_control }

-- Advanced
labels[#labels + 1] = { t = "高级参数",       x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "缓启动时间",           x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.soft_start }
fields[#fields + 1] = { t = "熄火反悔时间",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.auto_restart_time }
fields[#fields + 1] = { t = "熄火重启加速度",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.restart_acc }
fields[#fields + 1] = { t = "定速器参数 P",                x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.p_gain }
fields[#fields + 1] = { t = "定速器参数 I",                x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.i_gain }
fields[#fields + 1] = { t = "同步整流",       x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.active_freewheel }
fields[#fields + 1] = { t = "驱动频率 [KHz]",     x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.drive_freq }
fields[#fields + 1] = { t = "电机最大电气转速",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.max_motor_erpm }

-- Other
labels[#labels + 1] = { t = "其他参数",          x = x, y = incY(lineSpacing) }
fields[#fields + 1] = { t = "油门协议",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.throttle_protocol }
fields[#fields + 1] = { t = "遥测协议",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.telemetry_protocol }
fields[#fields + 1] = { t = "彩灯颜色",                 x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.led_color }
fields[#fields + 1] = { t = "电机温度传感器",   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.motor_temp_sensor }
fields[#fields + 1] = { t = "电机温度保护阈值",    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.motor_temp }
fields[#fields + 1] = { t = "消耗容量保护阈值 [mAh]",      x = x + indent, y = incY(lineSpacing), sp = x + sp, data = escParameters.capacity_cutoff }

local function receivedEscParameters(page, data)
    if data.esc_signature ~= 115 then -- Flyrotor signature
        page.labels[1].t = "检测到无效的电调"
    else
        page.labels[1].t = string.format("FLYROTOR %dA%s", data.amperage, data.type == 1 and " F3C" or "")
        page.labels[2].t = string.format("序列号: %08X%08X", data.serial_number1, data.serial_number2)
        page.labels[3].t = string.format("硬件: 1.%d - IAP: %d.%d.%d", data.hw_version, data.iap_major, data.iap_minor, data.iap_patch)
        page.labels[4].t = string.format("固件: %d.%d.%d", data.fw_major, data.fw_minor, data.fw_patch)
        page.labels[5].t = string.format("油门行程: %d-%dus", data.thr_min, data.thr_max)
        page.readOnly = bit32.band(data.command, 0x40) == 0x40
    end

    rf2.onPageReady(page)
end

return {
    read = function(self)
        rf2.useApi(mspEscFlyrotor).read(receivedEscParameters, self, escParameters)
    end,
    write = function(self)
        rf2.useApi(mspEscFlyrotor).write(escParameters)
        rf2.settingsSaved(false, false)
    end,
    title       = "FLYROTOR Setup",
    labels      = labels,
    fields      = fields,
    readOnly    = true
}
