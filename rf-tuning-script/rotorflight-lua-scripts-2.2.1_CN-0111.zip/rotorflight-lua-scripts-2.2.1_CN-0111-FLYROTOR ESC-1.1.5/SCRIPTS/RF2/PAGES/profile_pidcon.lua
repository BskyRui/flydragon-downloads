﻿local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
template = nil
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local profileSwitcher = rf2.executeScript("PAGES/helpers/profileSwitcher.lua")
local pidProfile = rf2.useApi("mspPidProfile").getDefaults()
collectgarbage()

fields[#fields + 1] = { t = "目前 PID 配置文件",     x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = profileSwitcher.startPidEditing, postEdit = profileSwitcher.endPidEditing }

incY(lineSpacing * 0.25)
fields[#fields + 1] = { t = "自旋补偿",       x = x,          y = incY(lineSpacing), sp = x + sp, data = pidProfile[6] }
fields[#fields + 1] = { t = "I-term 释放类型",       x = x,          y = incY(lineSpacing), sp = x + sp, data = pidProfile[16] }
fields[#fields + 1] = { t = "横滚截止点",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[17] }
fields[#fields + 1] = { t = "俯仰截止点",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[18] }
fields[#fields + 1] = { t = "航向截止点",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[19] }
labels[#labels + 1] = { t = "Ground 误差衰减",      x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "时间",                    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[1] }
labels[#labels + 1] = { t = "循环误差衰减",      x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "时间",                    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[2] }
fields[#fields + 1] = { t = "限制",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[4] }
labels[#labels + 1] = { t = "航向误差衰减",         x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "时间",                    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[3] }
fields[#fields + 1] = { t = "限制",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[5] }
labels[#labels + 1] = { t = "误差限制",             x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "横滚",                    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[7] }
fields[#fields + 1] = { t = "俯仰",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[8] }
fields[#fields + 1] = { t = "航向",                     x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[9] }
labels[#labels + 1] = { t = "HSI 偏移限制",        x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "横滚",                    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[36] }
fields[#fields + 1] = { t = "俯仰",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[37] }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "PID 控制器带宽",          x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "横滚带宽[Hz]",             x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[10] }
fields[#fields + 1] = { t = "俯仰带宽[Hz]",             x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[11] }
fields[#fields + 1] = { t = "航向带宽[Hz]",             x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[12] }
fields[#fields + 1] = { t = "横滚 D 截止[Hz]",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[13] }
fields[#fields + 1] = { t = "俯仰 D 截止[Hz]",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[14] }
fields[#fields + 1] = { t = "航向 D 截止[Hz]",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[15] }
fields[#fields + 1] = { t = "横滚 B 截止[Hz]",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[38] }
fields[#fields + 1] = { t = "俯仰 B 截止[Hz]",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[39] }
fields[#fields + 1] = { t = "航向 B 截止[Hz]",         x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[40] }

local function receivedPidProfile(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        self.profileSwitcher.getStatus(self)
        rf2.useApi("mspPidProfile").read(receivedPidProfile, self, pidProfile)
    end,
    write = function(self)
        rf2.useApi("mspPidProfile").write(pidProfile)
        rf2.settingsSaved(true, false)
    end,
    title       = "飞行参数 - PIDs 进阶",
    labels      = labels,
    fields      = fields,
    profileSwitcher = profileSwitcher,

    timer = function(self)
        self.profileSwitcher.checkStatus(self)
    end,
}

