﻿local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local filterConfig = rf2.useApi("mspFilterConfig").getDefaults()

labels[#labels + 1] = { t = "陀螺仪低通滤波器 1",           x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "滤波器类型",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_lpf1_type }
fields[#fields + 1] = { t = "截止频率",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_lpf1_static_hz }
labels[#labels + 1] = { t = "陀螺仪低通滤波器 1 动态",   x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "最小截止频率",               x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_lpf1_dyn_min_hz }
fields[#fields + 1] = { t = "最大截止频率",               x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_lpf1_dyn_max_hz }
labels[#labels + 1] = { t = "陀螺仪低通滤波器 2",           x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "滤波器类型",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_lpf2_type }
fields[#fields + 1] = { t = "截止频率",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_lpf2_static_hz }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "陀螺仪陷波滤波器 1",             x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "中心频率",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_soft_notch_hz_1 }
fields[#fields + 1] = { t = "截止频率",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_soft_notch_cutoff_1 }
labels[#labels + 1] = { t = "陀螺仪陷波滤波器 2",             x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "中心频率",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_soft_notch_hz_2 }
fields[#fields + 1] = { t = "截止频率",                   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.gyro_soft_notch_cutoff_2 }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "陀螺仪动态陷波滤波器",    x = x,          y = incY(lineSpacing) }
-- TODO: enable/disable dynamic notch filters by setting/clearing feature DYN_NOTCH (see MSP_FEATURE_CONFIG)
fields[#fields + 1] = { t = "数量",                    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.dyn_notch_count }
fields[#fields + 1] = { t = "Q 因子",                        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.dyn_notch_q }
fields[#fields + 1] = { t = "最小频率",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.dyn_notch_min_hz }
fields[#fields + 1] = { t = "最大频率",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = filterConfig.dyn_notch_max_hz}
-- TODO: preset and min_hz for API >= 12.08

local function receivedFilterConfig(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        rf2.useApi("mspFilterConfig").read(receivedFilterConfig, self, filterConfig)
    end,
    write = function(self)
        rf2.useApi("mspFilterConfig").write(filterConfig)
        rf2.settingsSaved(true, true)
    end,
    title       = "滤波器",
    labels      = labels,
    fields      = fields,
}

