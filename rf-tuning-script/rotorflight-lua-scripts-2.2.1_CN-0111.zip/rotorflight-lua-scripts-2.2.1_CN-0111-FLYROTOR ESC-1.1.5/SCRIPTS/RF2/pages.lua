﻿local PageFiles = {}
local settings = rf2.loadSettings()

-- Rotorflight pages.
PageFiles[#PageFiles + 1] = { title = "状态", script = "status" }
PageFiles[#PageFiles + 1] = { title = "速率", script = "rates" }
PageFiles[#PageFiles + 1] = { title = "速率-动态", script = "rate_dynamics" }
PageFiles[#PageFiles + 1] = { title = "PIDs ", script = "profile_pids" }
PageFiles[#PageFiles + 1] = { title = "PIDs进阶", script = "profile_pidcon" }
PageFiles[#PageFiles + 1] = { title = "飞行参数-其他", script = "profile_various" }
PageFiles[#PageFiles + 1] = { title = "飞行参数-救机", script = "profile_rescue" }
PageFiles[#PageFiles + 1] = { title = "飞行参数-定速器", script = "profile_governor" }
PageFiles[#PageFiles + 1] = { title = "舵机", script = "servos" }
PageFiles[#PageFiles + 1] = { title = "混控", script = "mixer" }
PageFiles[#PageFiles + 1] = { title = "滤波器", script = "filters" }
PageFiles[#PageFiles + 1] = { title = "定速器", script = "governor" }
PageFiles[#PageFiles + 1] = { title = "加速度计", script = "accelerometer" }

if rf2.apiVersion >= 12.07 then
    if settings.showModelOnTx == 1 then
        PageFiles[#PageFiles + 1] = { title = "显示模型", script = "model" }
    end
    if settings.showExperimental == 1 then
        PageFiles[#PageFiles + 1] = { title = "Experimental (!)", script = "experimental" }
    end
    if settings.showFlyRotor == 1 then
        PageFiles[#PageFiles + 1] = { title = "电调 - FLYROTOR", script = "esc_flyrotor" }
    end
    if settings.showPlatinumV5 == 1 then
        PageFiles[#PageFiles + 1] = { title = "电调 - HW Platinum V5", script = "esc_hwpl5" }
    end
    if settings.showTribunus == 1 then
        PageFiles[#PageFiles + 1] = { title = "电调 - Scorpion Tribunus", script = "esc_scorp" }
    end
    if rf2.apiVersion >= 12.08 and settings.showXdfly == 1 then
        PageFiles[#PageFiles + 1] = { title = "电调 - XDFly", script = "esc_xdfly" }
    end
    if settings.showYge == 1 then
        PageFiles[#PageFiles + 1] = { title = "电调 - YGE", script = "esc_yge" }
    end

    PageFiles[#PageFiles + 1] = { title = "设定", script = "settings" }
end

return PageFiles

